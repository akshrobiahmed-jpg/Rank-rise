package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.StudyViewModel
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.CyberEmeraldSuccess
import com.example.ui.theme.CyberPurplePrimary
import com.example.ui.theme.CyberRoseDanger
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceBorder
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class DailyStudyTask(
    val id: String,
    val title: String,
    val subtitle: String,
    val type: String, // "STUDY", "REVISION", "MOCK"
    val durationMinutes: Int,
    val isDone: Boolean = false
)

@Composable
fun PlannerScreen(
    viewModel: StudyViewModel,
    modifier: Modifier = Modifier
) {
    val examTimestamp by viewModel.examTargetTimestamp.collectAsStateWithLifecycle()
    val chapters by viewModel.chapters.collectAsStateWithLifecycle()
    val subjects by viewModel.subjects.collectAsStateWithLifecycle()
    val dailyTargetHours by viewModel.dailyTargetHours.collectAsStateWithLifecycle()

    val remainingDays = ((examTimestamp - System.currentTimeMillis()) / (24 * 60 * 60 * 1000L)).coerceAtLeast(1).toInt()
    val remainingChapters = chapters.filter { it.completionPercent < 100 }
    val chaptersPerDay = if (remainingDays > 0) {
        kotlin.math.ceil(remainingChapters.size.toFloat() / remainingDays).toInt().coerceAtLeast(1)
    } else 1

    var showEditDaysDialog by remember { mutableStateOf(false) }

    // Dynamically generated daily tasks for today
    val generatedTasks = remember(remainingChapters, remainingDays) {
        val list = mutableListOf<DailyStudyTask>()
        val topChapters = remainingChapters.take(2)
        topChapters.forEachIndexed { idx, ch ->
            val sub = subjects.firstOrNull { it.id == ch.subjectId }?.name ?: "Science"
            list.add(
                DailyStudyTask(
                    id = "task_$idx",
                    title = "Study: ${ch.title}",
                    subtitle = "$sub • Target 45 mins",
                    type = "STUDY",
                    durationMinutes = 45
                )
            )
        }
        list.add(
            DailyStudyTask(
                id = "task_rev",
                title = "Spaced Repetition Review",
                subtitle = "Complete pending Leitner cards • 15 mins",
                type = "REVISION",
                durationMinutes = 15
            )
        )
        list.add(
            DailyStudyTask(
                id = "task_mock",
                title = "Timed MCQ Self-Test",
                subtitle = "Class 9 Science practice test • 15 mins",
                type = "MOCK",
                durationMinutes = 15
            )
        )
        list
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.currentScreen.value = "dashboard" },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(CyberSurfaceVariant)
                ) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary, modifier = Modifier.size(20.dp))
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "30-DAY EXAM PLANNER",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyanSecondary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Adaptive Preparation Schedule",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                }
            }
        }

        // 30-DAY ADAPTIVE BANNER
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(CyberPurplePrimary, CyberCyanSecondary))
                )
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "DAYS REMAINING", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextSecondary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "$remainingDays Days", fontSize = 32.sp, fontWeight = FontWeight.Black, color = TextPrimary)
                        }

                        IconButton(
                            onClick = { showEditDaysDialog = true },
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(CyberSurfaceVariant)
                                .testTag("edit_exam_date_button")
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Days", tint = CyberCyanSecondary, modifier = Modifier.size(20.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Daily Target", fontSize = 11.sp, color = TextMuted)
                            Text(text = "${chaptersPerDay} Chapters/day", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CyberPurplePrimary)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Study Hours/day", fontSize = 11.sp, color = TextMuted)
                            Text(text = "${dailyTargetHours.toInt()} Hours/day", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CyberCyanSecondary)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "Remaining", fontSize = 11.sp, color = TextMuted)
                            Text(text = "${remainingChapters.size} Chapters", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CyberRoseDanger)
                        }
                    }
                }
            }
        }

        // TODAY'S ADAPTIVE STUDY CHECKLIST
        item {
            Text(
                text = "Today's Generated Study Tasks",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        items(generatedTasks) { task ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val icon = when (task.type) {
                            "REVISION" -> Icons.Default.Psychology
                            "MOCK" -> Icons.Default.Quiz
                            else -> Icons.Default.Assignment
                        }
                        val tint = when (task.type) {
                            "REVISION" -> CyberCyanSecondary
                            "MOCK" -> CyberEmeraldSuccess
                            else -> CyberPurplePrimary
                        }
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(tint.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = task.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(text = task.subtitle, fontSize = 12.sp, color = TextSecondary)
                        }
                    }

                    Button(
                        onClick = {
                            when (task.type) {
                                "REVISION" -> viewModel.currentScreen.value = "revision"
                                "MOCK" -> viewModel.startMockExam("Physics")
                                else -> {
                                    viewModel.currentScreen.value = "timer"
                                    viewModel.startTimer()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberSurface),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = CyberCyanSecondary, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Start", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showEditDaysDialog) {
        var daysInput by remember { mutableStateOf(remainingDays.toString()) }

        AlertDialog(
            onDismissRequest = { showEditDaysDialog = false },
            containerColor = CyberSurface,
            title = { Text("Update Exam Countdown", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = daysInput,
                    onValueChange = { daysInput = it },
                    label = { Text("Days until exam (e.g. 30)") },
                    modifier = Modifier.fillMaxWidth().testTag("exam_days_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = CyberPurplePrimary,
                        unfocusedBorderColor = CyberSurfaceBorder
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val d = daysInput.toIntOrNull() ?: 30
                        viewModel.updateTargetExamDays(d)
                        showEditDaysDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberPurplePrimary),
                    modifier = Modifier.testTag("confirm_exam_days_button")
                ) {
                    Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Button(onClick = { showEditDaysDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceVariant)) {
                    Text("Cancel", color = TextPrimary)
                }
            }
        )
    }
}
