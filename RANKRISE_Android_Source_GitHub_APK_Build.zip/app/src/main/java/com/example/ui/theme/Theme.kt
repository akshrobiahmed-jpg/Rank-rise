package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CyberDarkColorScheme = darkColorScheme(
    primary = CyberPurplePrimary,
    onPrimary = Color.Black,
    primaryContainer = CyberPurpleContainer,
    onPrimaryContainer = CyberOnPurpleContainer,
    secondary = CyberCyanSecondary,
    onSecondary = Color.Black,
    secondaryContainer = CyberCyanContainer,
    onSecondaryContainer = CyberOnCyanContainer,
    tertiary = CyberNeonBlue,
    background = CyberBackground,
    onBackground = TextPrimary,
    surface = CyberSurface,
    onSurface = TextPrimary,
    surfaceVariant = CyberSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = CyberSurfaceBorder,
    error = CyberRoseDanger,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false, // Keep consistent cyber aesthetic
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = CyberDarkColorScheme,
        typography = Typography,
        content = content
    )
}
