package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.StudyViewModel
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.CyberEmeraldSuccess
import com.example.ui.theme.CyberPurplePrimary
import com.example.ui.theme.CyberRoseDanger
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceBorder
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MockExamsScreen(
    viewModel: StudyViewModel,
    modifier: Modifier = Modifier
) {
    val quizSubject by viewModel.currentQuizSubject.collectAsStateWithLifecycle()
    val questions by viewModel.currentQuizQuestions.collectAsStateWithLifecycle()
    val selectedAnswers by viewModel.quizSelectedAnswers.collectAsStateWithLifecycle()
    val isFinished by viewModel.isQuizFinished.collectAsStateWithLifecycle()
    val pastExams by viewModel.mockExams.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.currentScreen.value = "dashboard" },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(CyberSurfaceVariant)
                ) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary, modifier = Modifier.size(20.dp))
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "TIMED MOCK EXAM",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyanSecondary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Class 9 $quizSubject Assessment",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                }
            }
        }

        // SUBJECT CHOOSER
        item {
            val subjects = listOf("Physics", "Chemistry", "Biology", "General Math")
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(subjects) { sub ->
                    val isCurrent = quizSubject == sub
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isCurrent) CyberPurplePrimary else CyberSurfaceVariant)
                            .clickable { viewModel.startMockExam(sub) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .testTag("mock_subject_$sub")
                    ) {
                        Text(
                            text = sub,
                            fontSize = 12.sp,
                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                            color = if (isCurrent) Color.Black else TextPrimary
                        )
                    }
                }
            }
        }

        if (questions.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberSurface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(imageVector = Icons.Default.Quiz, contentDescription = null, tint = CyberCyanSecondary, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(text = "Select a subject above to generate an instant timed test!", fontSize = 14.sp, color = TextSecondary, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            }
        } else {
            // ACTIVE QUIZ QUESTIONS
            items(questions.indices.toList()) { index ->
                val q = questions[index]
                val selectedOpt = selectedAnswers[index]

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Question ${index + 1} of ${questions.size}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberCyanSecondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = q.question,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        q.options.forEachIndexed { optIndex, optionText ->
                            val isSelected = selectedOpt == optIndex
                            val isCorrect = q.correctIndex == optIndex
                            val optionBorder = when {
                                isFinished && isCorrect -> CyberEmeraldSuccess
                                isFinished && isSelected && !isCorrect -> CyberRoseDanger
                                isSelected -> CyberPurplePrimary
                                else -> CyberSurfaceBorder
                            }

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        when {
                                            isFinished && isCorrect -> CyberEmeraldSuccess.copy(alpha = 0.2f)
                                            isFinished && isSelected && !isCorrect -> CyberRoseDanger.copy(alpha = 0.2f)
                                            isSelected -> CyberPurplePrimary.copy(alpha = 0.15f)
                                            else -> CyberSurface
                                        }
                                    )
                                    .border(1.dp, optionBorder, RoundedCornerShape(10.dp))
                                    .clickable(enabled = !isFinished) {
                                        viewModel.selectQuizAnswer(index, optIndex)
                                    }
                                    .padding(horizontal = 14.dp, vertical = 10.dp)
                                    .testTag("quiz_q${index}_opt$optIndex")
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${('A' + optIndex)}. $optionText",
                                        fontSize = 13.sp,
                                        color = TextPrimary
                                    )
                                    if (isFinished) {
                                        if (isCorrect) {
                                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = CyberEmeraldSuccess, modifier = Modifier.size(16.dp))
                                        } else if (isSelected) {
                                            Icon(imageVector = Icons.Default.Close, contentDescription = null, tint = CyberRoseDanger, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                }
                            }
                        }

                        if (isFinished) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CyberSurface)
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = "💡 Explanation: ${q.explanation}",
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }

            // SUBMIT QUIZ BUTTON
            if (!isFinished) {
                item {
                    Button(
                        onClick = { viewModel.finishMockExam() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_quiz_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CyberEmeraldSuccess)
                    ) {
                        Text(
                            text = "Submit & Analyze Mistakes",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                }
            } else {
                // RESULTS BANNER
                item {
                    val correctCount = questions.indices.count { selectedAnswers[it] == questions[it].correctIndex }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = CyberSurface),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = androidx.compose.ui.graphics.SolidColor(CyberEmeraldSuccess)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "EXAM RESULT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyberEmeraldSuccess)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$correctCount / ${questions.size} Correct (${(correctCount * 100 / questions.size)}%)",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (correctCount == questions.size) "Perfect score! Outstanding Class 9 preparation!" else "Review the explanations above to solidify weak areas before exam day.",
                                fontSize = 12.sp,
                                color = TextMuted,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // PAST EXAM HISTORY
        item {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Previous Mock Exam History (${pastExams.size})",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        if (pastExams.isEmpty()) {
            item {
                Text(text = "No previous mock exams recorded yet.", fontSize = 12.sp, color = TextMuted)
            }
        } else {
            items(pastExams) { exam ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberSurface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = exam.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            val df = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
                            Text(text = df.format(Date(exam.timestamp)), fontSize = 11.sp, color = TextMuted)
                        }

                        Text(
                            text = "${exam.score} / ${exam.totalQuestions}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            color = if (exam.score >= exam.totalQuestions / 2) CyberEmeraldSuccess else CyberRoseDanger
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
