package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.entity.ChapterEntity
import com.example.data.entity.SubjectEntity
import com.example.ui.StudyViewModel
import com.example.ui.theme.CyberAmberAlert
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.CyberEmeraldSuccess
import com.example.ui.theme.CyberPurplePrimary
import com.example.ui.theme.CyberRoseDanger
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceBorder
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SubjectsScreen(
    viewModel: StudyViewModel,
    modifier: Modifier = Modifier
) {
    val subjects by viewModel.subjects.collectAsStateWithLifecycle()
    val chapters by viewModel.chapters.collectAsStateWithLifecycle()

    var activeSubject by remember { mutableStateOf<SubjectEntity?>(null) }
    var showAddChapterDialog by remember { mutableStateOf(false) }
    var selectedChapterForPhoto by remember { mutableStateOf<ChapterEntity?>(null) }

    // Android Photo Picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let {
            selectedChapterForPhoto?.let { ch ->
                viewModel.attachPhotoToChapter(ch, it.toString())
                selectedChapterForPhoto = null
            }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        if (activeSubject == null) {
            // MAIN SUBJECTS OVERVIEW
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "BANGLADESH CLASS 9 SCIENCE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyanSecondary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Subjects & Syllabus Tracker",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary
                    )
                    Text(
                        text = "Tap a subject to view chapters, upload syllabus photos, and update progress.",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                }

                items(subjects) { subject ->
                    val subjectChapters = chapters.filter { it.subjectId == subject.id }
                    val avgCompletion = if (subjectChapters.isNotEmpty()) {
                        subjectChapters.map { it.completionPercent }.average().toInt()
                    } else 0

                    SubjectCard(
                        subject = subject,
                        chaptersCount = subjectChapters.size,
                        completionPercent = avgCompletion,
                        onOpen = { activeSubject = subject },
                        onToggleWeak = { viewModel.toggleSubjectWeak(subject) }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        } else {
            // CHAPTER DRILL-DOWN VIEW FOR SELECTED SUBJECT
            val currentSubject = activeSubject!!
            val subjectChapters = chapters.filter { it.subjectId == currentSubject.id }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { activeSubject = null },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(CyberSurfaceVariant)
                                .testTag("back_to_subjects_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Back",
                                tint = TextPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = currentSubject.name,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = TextPrimary
                            )
                            Text(
                                text = currentSubject.banglaName,
                                fontSize = 13.sp,
                                color = CyberCyanSecondary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                if (subjectChapters.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No chapters added yet for this subject.\nTap '+' below to add your syllabus chapters!",
                                color = TextMuted,
                                fontSize = 14.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                } else {
                    items(subjectChapters) { chapter ->
                        ChapterItemCard(
                            chapter = chapter,
                            onProgressChange = { newPercent ->
                                viewModel.updateChapterProgress(chapter, newPercent)
                            },
                            onAttachPhoto = {
                                selectedChapterForPhoto = chapter
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            onStudyNow = {
                                viewModel.selectedSubjectForTimer.value = currentSubject
                                viewModel.selectedChapterForTimer.value = chapter.title
                                viewModel.currentScreen.value = "timer"
                            },
                            onDelete = { viewModel.deleteChapter(chapter.id) }
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(80.dp))
                }
            }

            // Floating Action Button to Add Chapter
            FloatingActionButton(
                onClick = { showAddChapterDialog = true },
                containerColor = CyberPurplePrimary,
                contentColor = Color.Black,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(20.dp)
                    .testTag("add_chapter_fab")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Add Chapter")
            }
        }

        // ADD CHAPTER DIALOG
        if (showAddChapterDialog && activeSubject != null) {
            AddChapterDialog(
                subjectName = activeSubject!!.name,
                onDismiss = { showAddChapterDialog = false },
                onConfirm = { title, banglaTitle, difficulty ->
                    viewModel.addChapter(
                        subjectId = activeSubject!!.id,
                        title = title,
                        banglaTitle = banglaTitle,
                        difficulty = difficulty
                    )
                    showAddChapterDialog = false
                }
            )
        }
    }
}

@Composable
fun SubjectCard(
    subject: SubjectEntity,
    chaptersCount: Int,
    completionPercent: Int,
    onOpen: () -> Unit,
    onToggleWeak: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpen() }
            .testTag("subject_card_${subject.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(
                if (subject.isWeak) CyberRoseDanger.copy(alpha = 0.5f) else CyberSurfaceBorder
            )
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = subject.name,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = subject.banglaName,
                        fontSize = 13.sp,
                        color = CyberCyanSecondary,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Weak subject flag toggle
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (subject.isWeak) CyberRoseDanger.copy(alpha = 0.2f) else CyberSurfaceVariant)
                        .border(1.dp, if (subject.isWeak) CyberRoseDanger else CyberSurfaceBorder, RoundedCornerShape(12.dp))
                        .clickable { onToggleWeak() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("weak_toggle_${subject.id}")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (subject.isWeak) {
                            Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = CyberRoseDanger, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                        }
                        Text(
                            text = if (subject.isWeak) "Weak Subject" else "Mark Weak",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (subject.isWeak) CyberRoseDanger else TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Progress bar & chapter count
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "$chaptersCount Chapters Listed",
                    fontSize = 12.sp,
                    color = TextMuted
                )
                Text(
                    text = "$completionPercent% Prepared",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberPurplePrimary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            LinearProgressIndicator(
                progress = { completionPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = CyberPurplePrimary,
                trackColor = CyberSurfaceVariant
            )
        }
    }
}

@Composable
fun ChapterItemCard(
    chapter: ChapterEntity,
    onProgressChange: (Int) -> Unit,
    onAttachPhoto: () -> Unit,
    onStudyNow: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chapter_card_${chapter.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Ch ${chapter.chapterNumber}: ${chapter.title}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    if (chapter.banglaTitle.isNotBlank()) {
                        Text(
                            text = chapter.banglaTitle,
                            fontSize = 12.sp,
                            color = CyberCyanSecondary
                        )
                    }
                }

                // Difficulty badge
                val diffColor = when (chapter.difficulty) {
                    "EASY" -> CyberEmeraldSuccess
                    "HARD" -> CyberRoseDanger
                    else -> CyberAmberAlert
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(diffColor.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = chapter.difficulty,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = diffColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Completion Progress Slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Completion: ${chapter.completionPercent}%",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextSecondary
                )
                if (chapter.completionPercent >= 100) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = CyberEmeraldSuccess, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(text = "Mastered", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyberEmeraldSuccess)
                    }
                }
            }

            Slider(
                value = chapter.completionPercent.toFloat(),
                onValueChange = { onProgressChange(it.toInt()) },
                valueRange = 0f..100f,
                colors = SliderDefaults.colors(thumbColor = CyberPurplePrimary, activeTrackColor = CyberPurplePrimary),
                modifier = Modifier.testTag("chapter_slider_${chapter.id}")
            )

            // Attached Photo Preview or Upload Button
            if (chapter.photoUri != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, CyberSurfaceBorder, RoundedCornerShape(12.dp))
                ) {
                    AsyncImage(
                        model = chapter.photoUri,
                        contentDescription = "Chapter Syllabus/Notes Photo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    // Change photo overlay
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.7f))
                            .clickable { onAttachPhoto() }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(text = "Replace Photo", fontSize = 11.sp, color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Action row: Attach Photo, Study Now, Delete
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row {
                    Button(
                        onClick = onAttachPhoto,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberSurface),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("attach_photo_chapter_${chapter.id}")
                    ) {
                        Icon(imageVector = Icons.Default.AddAPhoto, contentDescription = null, tint = CyberCyanSecondary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = if (chapter.photoUri == null) "Upload Photo" else "View / Change", fontSize = 11.sp, color = TextPrimary)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = TextMuted, modifier = Modifier.size(18.dp))
                    }
                }

                Button(
                    onClick = onStudyNow,
                    colors = ButtonDefaults.buttonColors(containerColor = CyberPurplePrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("study_now_chapter_${chapter.id}")
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Focus", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                }
            }
        }
    }
}

@Composable
fun AddChapterDialog(
    subjectName: String,
    onDismiss: () -> Unit,
    onConfirm: (title: String, banglaTitle: String, difficulty: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var banglaTitle by remember { mutableStateOf("") }
    var difficulty by remember { mutableStateOf("MEDIUM") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberSurface,
        title = {
            Text(text = "Add Chapter to $subjectName", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Chapter Title (English)") },
                    modifier = Modifier.fillMaxWidth().testTag("add_chapter_title_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = CyberPurplePrimary,
                        unfocusedBorderColor = CyberSurfaceBorder
                    )
                )

                OutlinedTextField(
                    value = banglaTitle,
                    onValueChange = { banglaTitle = it },
                    label = { Text("অধ্যায়ের নাম (বাংলা)") },
                    modifier = Modifier.fillMaxWidth().testTag("add_chapter_bangla_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = CyberCyanSecondary,
                        unfocusedBorderColor = CyberSurfaceBorder
                    )
                )

                Text(text = "Difficulty Level:", fontSize = 12.sp, color = TextSecondary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("EASY", "MEDIUM", "HARD").forEach { diff ->
                        val isSelected = difficulty == diff
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) CyberPurplePrimary else CyberSurfaceVariant)
                                .clickable { difficulty = diff }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = diff,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.Black else TextPrimary
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(title, banglaTitle, difficulty)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyberPurplePrimary),
                modifier = Modifier.testTag("confirm_add_chapter_button")
            ) {
                Text("Add Chapter", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceVariant)
            ) {
                Text("Cancel", color = TextPrimary)
            }
        }
    )
}
