package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.StudyViewModel
import com.example.ui.TimerMode
import com.example.ui.TimerStatus
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.CyberEmeraldSuccess
import com.example.ui.theme.CyberNeonBlue
import com.example.ui.theme.CyberPurplePrimary
import com.example.ui.theme.CyberRoseDanger
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceBorder
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun TimerScreen(
    viewModel: StudyViewModel,
    modifier: Modifier = Modifier
) {
    val timerMode by viewModel.timerMode.collectAsStateWithLifecycle()
    val timerStatus by viewModel.timerStatus.collectAsStateWithLifecycle()
    val remainingSeconds by viewModel.timerRemainingSeconds.collectAsStateWithLifecycle()
    val stopwatchSeconds by viewModel.stopwatchElapsedSeconds.collectAsStateWithLifecycle()
    val isBreakMode by viewModel.isBreakMode.collectAsStateWithLifecycle()
    val customMinutes by viewModel.customStudyMinutes.collectAsStateWithLifecycle()

    val subjects by viewModel.subjects.collectAsStateWithLifecycle()
    val selectedSubject by viewModel.selectedSubjectForTimer.collectAsStateWithLifecycle()
    val isShieldEnabled by viewModel.isExamLockShieldEnabled.collectAsStateWithLifecycle()

    val totalSeconds = if (timerMode == TimerMode.STOPWATCH) {
        (stopwatchSeconds).coerceAtLeast(1)
    } else if (isBreakMode) {
        timerMode.breakSeconds
    } else if (timerMode == TimerMode.CUSTOM) {
        customMinutes * 60
    } else {
        timerMode.studySeconds
    }

    val progressFraction = if (timerMode == TimerMode.STOPWATCH) {
        ((stopwatchSeconds % 60) / 60f)
    } else {
        if (totalSeconds > 0) (remainingSeconds.toFloat() / totalSeconds).coerceIn(0f, 1f) else 0f
    }

    val displaySeconds = if (timerMode == TimerMode.STOPWATCH) stopwatchSeconds else remainingSeconds
    val minutes = displaySeconds / 60
    val seconds = displaySeconds % 60
    val timeFormatted = String.format(Locale.US, "%02d:%02d", minutes, seconds)

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Screen Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "ADVANCED FOCUS TIMER",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberPurplePrimary,
                    letterSpacing = 1.sp
                )
                Text(
                    text = if (isBreakMode) "Rest & Rejuvenate (Break)" else "Class 9 Deep Study",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = TextPrimary
                )
            }

            // Distraction Shield Toggle Chip
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (isShieldEnabled) CyberSurfaceVariant else CyberSurface)
                    .border(1.dp, if (isShieldEnabled) CyberCyanSecondary.copy(alpha = 0.5f) else CyberSurfaceBorder, RoundedCornerShape(20.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Shield",
                    tint = if (isShieldEnabled) CyberCyanSecondary else TextMuted,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Switch(
                    checked = isShieldEnabled,
                    onCheckedChange = { viewModel.isExamLockShieldEnabled.value = it },
                    modifier = Modifier.testTag("shield_toggle_switch"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = CyberCyanSecondary,
                        uncheckedTrackColor = CyberSurface
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // TIMER PRESET SELECTOR CHIPS
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(TimerMode.values()) { mode ->
                val isSelected = timerMode == mode
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (isSelected) CyberPurplePrimary else CyberSurfaceVariant)
                        .border(1.dp, if (isSelected) CyberPurplePrimary else CyberSurfaceBorder, RoundedCornerShape(14.dp))
                        .clickable { viewModel.setTimerMode(mode) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                        .testTag("timer_preset_${mode.name}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = mode.title,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.Black else TextPrimary
                    )
                }
            }
        }

        // Custom Slider if CUSTOM mode selected
        if (timerMode == TimerMode.CUSTOM) {
            Spacer(modifier = Modifier.height(12.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Custom Study Duration", fontSize = 12.sp, color = TextSecondary)
                        Text(text = "$customMinutes Minutes", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = CyberCyanSecondary)
                    }
                    Slider(
                        value = customMinutes.toFloat(),
                        onValueChange = { viewModel.setCustomMinutes(it.toInt()) },
                        valueRange = 5f..120f,
                        steps = 22,
                        colors = SliderDefaults.colors(thumbColor = CyberCyanSecondary, activeTrackColor = CyberCyanSecondary),
                        modifier = Modifier.testTag("custom_timer_slider")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // SUBJECT TAGGING SELECTOR
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "TAG STUDY SUBJECT",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(subjects) { sub ->
                    val isSubjectSelected = selectedSubject?.id == sub.id
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSubjectSelected) CyberCyanSecondary.copy(alpha = 0.2f) else CyberSurface)
                            .border(1.dp, if (isSubjectSelected) CyberCyanSecondary else CyberSurfaceBorder, RoundedCornerShape(12.dp))
                            .clickable { viewModel.selectedSubjectForTimer.value = sub }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .testTag("select_timer_subject_${sub.id}")
                    ) {
                        Text(
                            text = sub.name,
                            fontSize = 12.sp,
                            fontWeight = if (isSubjectSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSubjectSelected) CyberCyanSecondary else TextPrimary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // GLOWING CIRCULAR COUNTDOWN TIMER DIAL
        Box(
            modifier = Modifier
                .size(260.dp)
                .testTag("circular_timer_dial"),
            contentAlignment = Alignment.Center
        ) {
            val strokeColor = if (isBreakMode) CyberEmeraldSuccess else CyberPurplePrimary
            val glowColor = if (isBreakMode) CyberCyanSecondary else CyberNeonBlue

            Canvas(modifier = Modifier.fillMaxSize()) {
                // Background Track
                drawCircle(
                    color = Color(0xFF1B1436),
                    radius = size.minDimension / 2 - 12.dp.toPx(),
                    style = Stroke(width = 14.dp.toPx(), cap = StrokeCap.Round)
                )

                // Active Progress Arc
                val sweepAngle = progressFraction * 360f
                drawArc(
                    brush = Brush.sweepGradient(listOf(strokeColor, glowColor, strokeColor)),
                    startAngle = -90f,
                    sweepAngle = sweepAngle,
                    useCenter = false,
                    style = Stroke(width = 14.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // Central Digits & Status
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = timeFormatted,
                    fontSize = 54.sp,
                    fontWeight = FontWeight.Black,
                    color = TextPrimary,
                    letterSpacing = 2.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            when (timerStatus) {
                                TimerStatus.RUNNING -> (if (isBreakMode) CyberEmeraldSuccess else CyberPurplePrimary).copy(alpha = 0.2f)
                                TimerStatus.PAUSED -> CyberRoseDanger.copy(alpha = 0.2f)
                                else -> CyberSurfaceVariant
                            }
                        )
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = when (timerStatus) {
                            TimerStatus.RUNNING -> if (isBreakMode) "BREAK IN PROGRESS" else "FOCUSED STUDY"
                            TimerStatus.PAUSED -> "PAUSED"
                            TimerStatus.COMPLETED -> "SESSION COMPLETED"
                            TimerStatus.IDLE -> "READY TO STUDY"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (timerStatus) {
                            TimerStatus.RUNNING -> if (isBreakMode) CyberEmeraldSuccess else CyberPurplePrimary
                            TimerStatus.PAUSED -> CyberRoseDanger
                            else -> TextSecondary
                        }
                    )
                }

                if (selectedSubject != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = selectedSubject!!.name,
                        fontSize = 12.sp,
                        color = CyberCyanSecondary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // PRIMARY CONTROL BUTTONS (Play, Pause, Reset, Stop & Save)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Reset Button
            IconButton(
                onClick = { viewModel.resetTimer() },
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(CyberSurfaceVariant)
                    .testTag("timer_reset_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Reset",
                    tint = TextPrimary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(20.dp))

            // Main Play/Pause Button
            Button(
                onClick = {
                    if (timerStatus == TimerStatus.RUNNING) {
                        viewModel.pauseTimer()
                    } else {
                        viewModel.startTimer()
                    }
                },
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .testTag("timer_play_pause_button"),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isBreakMode) CyberEmeraldSuccess else CyberPurplePrimary
                )
            ) {
                Icon(
                    imageVector = if (timerStatus == TimerStatus.RUNNING) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (timerStatus == TimerStatus.RUNNING) "Pause" else "Start",
                    tint = Color.Black,
                    modifier = Modifier.size(38.dp)
                )
            }

            Spacer(modifier = Modifier.width(20.dp))

            // Stop and Save Button
            IconButton(
                onClick = { viewModel.stopAndSaveSession() },
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(CyberSurfaceVariant)
                    .testTag("timer_stop_save_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Stop,
                    contentDescription = "Save Session",
                    tint = CyberRoseDanger,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Distraction Shield explanation banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.currentScreen.value = "exam_lock_settings" },
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Lock",
                    tint = CyberCyanSecondary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Exam Lock Shield Active",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Blocks distracting apps during study. Tap to customize blocked app list.",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
