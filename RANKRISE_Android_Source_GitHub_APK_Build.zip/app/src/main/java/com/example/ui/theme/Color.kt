package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// RANKRISE Deep Cyber Dark Palette
val CyberBackground = Color(0xFF090614)
val CyberSurface = Color(0xFF130E26)
val CyberSurfaceVariant = Color(0xFF1F173D)
val CyberSurfaceBorder = Color(0xFF332463)

val CyberPurplePrimary = Color(0xFFA855F7)
val CyberPurpleSecondary = Color(0xFF9333EA)
val CyberPurpleContainer = Color(0xFF2E1065)
val CyberOnPurpleContainer = Color(0xFFE9D5FF)

val CyberCyanSecondary = Color(0xFF06B6D4)
val CyberCyanContainer = Color(0xFF083344)
val CyberOnCyanContainer = Color(0xFFA5F3FC)

val CyberNeonBlue = Color(0xFF38BDF8)
val CyberEmeraldSuccess = Color(0xFF10B981)
val CyberAmberAlert = Color(0xFFF59E0B)
val CyberRoseDanger = Color(0xFFF43F5E)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
