package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.RankRiseDatabase
import com.example.data.StudyRepository
import com.example.data.entity.ChapterEntity
import com.example.data.entity.DistractionAppEntity
import com.example.data.entity.MockExamEntity
import com.example.data.entity.RevisionCardEntity
import com.example.data.entity.StudySessionEntity
import com.example.data.entity.SubjectEntity
import com.example.service.AiChatMessage
import com.example.service.AiStudyCoachService
import com.example.service.ExamLockManager
import com.example.service.GeneratedMcq
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

enum class TimerMode(val title: String, val studySeconds: Int, val breakSeconds: Int) {
    POMO_25("25/5 Pomodoro", 25 * 60, 5 * 60),
    POMO_50("50/10 Focus", 50 * 60, 10 * 60),
    DEEP_90("90/15 Deep Work", 90 * 60, 15 * 60),
    CUSTOM("Custom Timer", 30 * 60, 5 * 60),
    STOPWATCH("Free Stopwatch", 0, 0)
}

enum class TimerStatus {
    IDLE, RUNNING, PAUSED, COMPLETED
}

class StudyViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: StudyRepository
    private val aiCoachService: AiStudyCoachService = AiStudyCoachService(application)

    init {
        val database = RankRiseDatabase.getDatabase(application, viewModelScope)
        repository = StudyRepository(database.studyDao())
    }

    // --- REACTIVE DATA STREAMS ---
    val subjects: StateFlow<List<SubjectEntity>> = repository.allSubjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chapters: StateFlow<List<ChapterEntity>> = repository.allChapters
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val studySessions: StateFlow<List<StudySessionEntity>> = repository.allSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val revisionCards: StateFlow<List<RevisionCardEntity>> = repository.allRevisionCards
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mockExams: StateFlow<List<MockExamEntity>> = repository.allMockExams
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val distractionApps: StateFlow<List<DistractionAppEntity>> = repository.distractionApps
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- NAVIGATION SELECTION ---
    val currentScreen = MutableStateFlow("dashboard") // "dashboard", "timer", "subjects", "revision", "ai_coach", "mock_exams", "planner", "exam_lock_settings"

    // --- DASHBOARD METRICS ---
    val examTargetTimestamp = MutableStateFlow(System.currentTimeMillis() + 30L * 24 * 60 * 60 * 1000) // 30 days default
    val dailyTargetHours = MutableStateFlow(5.0f) // 5 hours daily

    val todayStudySeconds: StateFlow<Int> = studySessions.combine(examTargetTimestamp) { sessions, _ ->
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val startOfDay = cal.timeInMillis
        sessions.filter { it.timestamp >= startOfDay }.sumOf { it.durationSeconds }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // --- TIMER STATE ---
    val timerMode = MutableStateFlow(TimerMode.POMO_25)
    val timerStatus = MutableStateFlow(TimerStatus.IDLE)
    val isBreakMode = MutableStateFlow(false)
    val customStudyMinutes = MutableStateFlow(30)

    val selectedSubjectForTimer = MutableStateFlow<SubjectEntity?>(null)
    val selectedChapterForTimer = MutableStateFlow("")

    val timerRemainingSeconds = MutableStateFlow(TimerMode.POMO_25.studySeconds)
    val stopwatchElapsedSeconds = MutableStateFlow(0)
    val isExamLockShieldEnabled = MutableStateFlow(true)

    private var timerJob: Job? = null
    private var lastTickTimestamp: Long = 0L

    // --- AI COACH STATE ---
    val aiMessages = MutableStateFlow<List<AiChatMessage>>(
        listOf(
            AiChatMessage(
                sender = "AI",
                text = "Assalamu Alaikum! I am your RANKRISE Study Coach for Class 9 Science. How can I help you prepare today? You can ask questions in English or বাংলা, or attach a photo of any textbook problem!"
            )
        )
    )
    val isAiLoading = MutableStateFlow(false)
    val aiSelectedSubject = MutableStateFlow("Physics")

    // --- ACTIVE MOCK EXAM STATE ---
    val currentQuizSubject = MutableStateFlow("Physics")
    val currentQuizQuestions = MutableStateFlow<List<GeneratedMcq>>(emptyList())
    val currentQuizIndex = MutableStateFlow(0)
    val quizSelectedAnswers = MutableStateFlow<Map<Int, Int>>(emptyMap())
    val isQuizFinished = MutableStateFlow(false)

    // --- DISTRACTION INTERCEPT NOTIFICATION ---
    val lastInterceptedApp = MutableStateFlow<String?>(null)

    init {
        // Observe ExamLockManager intercept events
        viewModelScope.launch {
            ExamLockManager.interceptEvent.collect { appName ->
                lastInterceptedApp.value = appName
            }
        }
    }

    fun dismissDistractionBanner() {
        lastInterceptedApp.value = null
    }

    // --- TIMER ACTIONS ---
    fun setTimerMode(mode: TimerMode) {
        if (timerStatus.value == TimerStatus.RUNNING) {
            pauseTimer()
        }
        timerMode.value = mode
        isBreakMode.value = false
        if (mode == TimerMode.STOPWATCH) {
            stopwatchElapsedSeconds.value = 0
            timerRemainingSeconds.value = 0
        } else if (mode == TimerMode.CUSTOM) {
            timerRemainingSeconds.value = customStudyMinutes.value * 60
        } else {
            timerRemainingSeconds.value = mode.studySeconds
        }
        timerStatus.value = TimerStatus.IDLE
    }

    fun setCustomMinutes(minutes: Int) {
        customStudyMinutes.value = minutes.coerceIn(5, 180)
        if (timerMode.value == TimerMode.CUSTOM && timerStatus.value == TimerStatus.IDLE) {
            timerRemainingSeconds.value = customStudyMinutes.value * 60
        }
    }

    fun startTimer() {
        if (timerStatus.value == TimerStatus.RUNNING) return

        timerStatus.value = TimerStatus.RUNNING
        lastTickTimestamp = System.currentTimeMillis()

        // Sync with Exam Lock Manager
        if (isExamLockShieldEnabled.value && !isBreakMode.value) {
            val blockedSet = distractionApps.value.filter { it.isBlocked }.map { it.packageName }.toSet()
            val subName = selectedSubjectForTimer.value?.name ?: "Class 9 Science"
            ExamLockManager.startFocusSession(subName, timerRemainingSeconds.value, blockedSet)
        }

        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (timerStatus.value == TimerStatus.RUNNING) {
                delay(1000)
                val now = System.currentTimeMillis()
                val deltaSeconds = ((now - lastTickTimestamp) / 1000).toInt().coerceAtLeast(1)
                lastTickTimestamp = now

                if (timerMode.value == TimerMode.STOPWATCH) {
                    stopwatchElapsedSeconds.value += deltaSeconds
                } else {
                    val current = timerRemainingSeconds.value
                    if (current <= deltaSeconds) {
                        timerRemainingSeconds.value = 0
                        onTimerFinished()
                        break
                    } else {
                        timerRemainingSeconds.value = current - deltaSeconds
                        ExamLockManager.updateRemainingTime(timerRemainingSeconds.value)
                    }
                }
            }
        }
    }

    fun pauseTimer() {
        timerStatus.value = TimerStatus.PAUSED
        timerJob?.cancel()
        ExamLockManager.stopFocusSession()
    }

    fun resetTimer() {
        pauseTimer()
        setTimerMode(timerMode.value)
    }

    fun stopAndSaveSession() {
        val secondsStudied = if (timerMode.value == TimerMode.STOPWATCH) {
            stopwatchElapsedSeconds.value
        } else {
            val totalPlanned = if (timerMode.value == TimerMode.CUSTOM) {
                customStudyMinutes.value * 60
            } else {
                timerMode.value.studySeconds
            }
            (totalPlanned - timerRemainingSeconds.value).coerceAtLeast(0)
        }

        pauseTimer()

        if (secondsStudied >= 10 && !isBreakMode.value) {
            val subject = selectedSubjectForTimer.value ?: subjects.value.firstOrNull()
            val subId = subject?.id ?: 1L
            val subName = subject?.name ?: "Science"
            val chTitle = selectedChapterForTimer.value.ifBlank { "General Preparation" }

            viewModelScope.launch {
                repository.saveSession(
                    StudySessionEntity(
                        subjectId = subId,
                        subjectName = subName,
                        chapterTitle = chTitle,
                        durationSeconds = secondsStudied,
                        mode = timerMode.value.name,
                        distractionsBlocked = ExamLockManager.distractionCount.value
                    )
                )
                ExamLockManager.resetDistractionCount()
            }
        }

        resetTimer()
    }

    private fun onTimerFinished() {
        timerStatus.value = TimerStatus.COMPLETED
        ExamLockManager.stopFocusSession()

        if (!isBreakMode.value && timerMode.value != TimerMode.STOPWATCH) {
            // Save completed study session
            val subject = selectedSubjectForTimer.value ?: subjects.value.firstOrNull()
            val plannedSeconds = if (timerMode.value == TimerMode.CUSTOM) customStudyMinutes.value * 60 else timerMode.value.studySeconds
            viewModelScope.launch {
                repository.saveSession(
                    StudySessionEntity(
                        subjectId = subject?.id ?: 1L,
                        subjectName = subject?.name ?: "Science",
                        chapterTitle = selectedChapterForTimer.value.ifBlank { "Focused Session" },
                        durationSeconds = plannedSeconds,
                        mode = timerMode.value.name,
                        distractionsBlocked = ExamLockManager.distractionCount.value
                    )
                )
                ExamLockManager.resetDistractionCount()
            }

            // Switch to break
            isBreakMode.value = true
            timerRemainingSeconds.value = timerMode.value.breakSeconds
            timerStatus.value = TimerStatus.IDLE
        } else if (isBreakMode.value) {
            // Break is done, return to study mode
            isBreakMode.value = false
            setTimerMode(timerMode.value)
        }
    }

    // --- SUBJECTS & CHAPTER ACTIONS ---
    fun addChapter(subjectId: Long, title: String, banglaTitle: String, difficulty: String, photoUri: String? = null) {
        viewModelScope.launch {
            val subjectChapters = chapters.value.filter { it.subjectId == subjectId }
            val nextNumber = (subjectChapters.maxOfOrNull { it.chapterNumber } ?: 0) + 1
            repository.insertChapter(
                ChapterEntity(
                    subjectId = subjectId,
                    chapterNumber = nextNumber,
                    title = title,
                    banglaTitle = banglaTitle,
                    difficulty = difficulty,
                    photoUri = photoUri,
                    completionPercent = 0
                )
            )
        }
    }

    fun updateChapterProgress(chapter: ChapterEntity, newPercent: Int) {
        viewModelScope.launch {
            repository.updateChapter(chapter.copy(completionPercent = newPercent.coerceIn(0, 100), lastStudiedTimestamp = System.currentTimeMillis()))
        }
    }

    fun attachPhotoToChapter(chapter: ChapterEntity, uriString: String) {
        viewModelScope.launch {
            repository.updateChapter(chapter.copy(photoUri = uriString))
        }
    }

    fun toggleSubjectWeak(subject: SubjectEntity) {
        viewModelScope.launch {
            repository.updateSubject(subject.copy(isWeak = !subject.isWeak))
        }
    }

    fun deleteChapter(chapterId: Long) {
        viewModelScope.launch {
            repository.deleteChapter(chapterId)
        }
    }

    // --- REVISION SPACED REPETITION ACTIONS ---
    // Intervals: 0 (same day), 1 (1 day), 2 (3 days), 3 (7 days), 4 (14 days)
    fun processRevisionReview(card: RevisionCardEntity, rating: String) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val dayMillis = 24 * 60 * 60 * 1000L

            val (nextStage, nextTimestamp) = when (rating) {
                "EASY" -> {
                    val next = (card.intervalStage + 1).coerceAtMost(4)
                    val daysToAdd = when (next) {
                        1 -> 1
                        2 -> 3
                        3 -> 7
                        else -> 14
                    }
                    Pair(next, now + daysToAdd * dayMillis)
                }
                "DIFFICULT" -> {
                    Pair(1, now + 1 * dayMillis)
                }
                else -> { // "FORGOT"
                    Pair(0, now + 4 * 60 * 60 * 1000L) // review again in 4 hours
                }
            }

            repository.updateRevisionCard(
                card.copy(
                    intervalStage = nextStage,
                    nextReviewTimestamp = nextTimestamp,
                    reviewCount = card.reviewCount + 1,
                    isMastered = nextStage >= 4
                )
            )
        }
    }

    fun addRevisionCard(subjectId: Long, subjectName: String, chapterName: String, topic: String, concept: String) {
        viewModelScope.launch {
            repository.insertRevisionCard(
                RevisionCardEntity(
                    subjectId = subjectId,
                    subjectName = subjectName,
                    chapterName = chapterName,
                    topicTitle = topic,
                    keyConcept = concept,
                    intervalStage = 0,
                    nextReviewTimestamp = System.currentTimeMillis()
                )
            )
        }
    }

    // --- DISTRACTION APPS ACTIONS ---
    fun toggleDistractionApp(app: DistractionAppEntity) {
        viewModelScope.launch {
            repository.updateDistractionApp(app.copy(isBlocked = !app.isBlocked))
        }
    }

    fun addCustomDistractionApp(name: String, packageName: String) {
        viewModelScope.launch {
            repository.insertDistractionApp(DistractionAppEntity(packageName = packageName, appName = name, isBlocked = true))
        }
    }

    // --- AI COACH ACTIONS ---
    fun sendAiPrompt(prompt: String, imageBitmap: Bitmap? = null) {
        if (prompt.isBlank() && imageBitmap == null) return

        val userMessage = AiChatMessage(
            sender = "USER",
            text = prompt.ifBlank { "Please analyze this textbook question/formula photo." },
            imageBitmap = imageBitmap
        )
        aiMessages.value = aiMessages.value + userMessage
        isAiLoading.value = true

        viewModelScope.launch {
            val responseText = aiCoachService.askCoach(
                prompt = prompt,
                subject = aiSelectedSubject.value,
                image = imageBitmap
            )
            aiMessages.value = aiMessages.value + AiChatMessage(
                sender = "AI",
                text = responseText
            )
            isAiLoading.value = false
        }
    }

    // --- MOCK EXAM ACTIONS ---
    fun startMockExam(subject: String) {
        currentQuizSubject.value = subject
        currentQuizQuestions.value = aiCoachService.generateQuickMcqs(subject)
        currentQuizIndex.value = 0
        quizSelectedAnswers.value = emptyMap()
        isQuizFinished.value = false
        currentScreen.value = "mock_exams"
    }

    fun selectQuizAnswer(questionIndex: Int, optionIndex: Int) {
        if (isQuizFinished.value) return
        quizSelectedAnswers.value = quizSelectedAnswers.value + (questionIndex to optionIndex)
    }

    fun finishMockExam() {
        isQuizFinished.value = true
        val questions = currentQuizQuestions.value
        val answers = quizSelectedAnswers.value
        var score = 0
        val weakTopics = mutableListOf<String>()

        questions.forEachIndexed { index, q ->
            if (answers[index] == q.correctIndex) {
                score++
            } else {
                weakTopics.add(q.question.take(30) + "...")
            }
        }

        viewModelScope.launch {
            repository.saveMockExam(
                MockExamEntity(
                    subjectName = currentQuizSubject.value,
                    title = "Class 9 ${currentQuizSubject.value} Timed Quiz",
                    score = score,
                    totalQuestions = questions.size,
                    timeTakenSeconds = 180,
                    weakTopics = weakTopics.joinToString(", ")
                )
            )
        }
    }

    fun updateTargetExamDays(days: Int) {
        val newTarget = System.currentTimeMillis() + days.coerceAtLeast(1) * 24L * 60 * 60 * 1000
        examTargetTimestamp.value = newTarget
    }
}
