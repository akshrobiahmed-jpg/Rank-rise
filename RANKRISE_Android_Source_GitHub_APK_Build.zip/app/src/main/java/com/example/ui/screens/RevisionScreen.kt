package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.RevisionCardEntity
import com.example.ui.StudyViewModel
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.CyberEmeraldSuccess
import com.example.ui.theme.CyberPurplePrimary
import com.example.ui.theme.CyberRoseDanger
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceBorder
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun RevisionScreen(
    viewModel: StudyViewModel,
    modifier: Modifier = Modifier
) {
    val revisionCards by viewModel.revisionCards.collectAsStateWithLifecycle()
    val subjects by viewModel.subjects.collectAsStateWithLifecycle()

    var showAddDialog by remember { mutableStateOf(false) }

    val now = System.currentTimeMillis()
    val dueCards = revisionCards.filter { it.nextReviewTimestamp <= now && !it.isMastered }
    val masteredCards = revisionCards.filter { it.isMastered }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "SPACED REPETITION REVISION CENTER",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyanSecondary,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Review & Memory Retention",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = TextPrimary
                )
                Text(
                    text = "Scientific intervals: Same day → 1 Day → 3 Days → 7 Days → 14 Days.",
                    fontSize = 12.sp,
                    color = TextMuted
                )
            }

            // SUMMARY CARDS
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = CyberSurface),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.linearGradient(listOf(CyberSurfaceBorder, CyberPurplePrimary.copy(alpha = 0.5f)))
                        )
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "Due Today", fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                                Icon(imageVector = Icons.Default.Schedule, contentDescription = null, tint = CyberPurplePrimary, modifier = Modifier.size(16.dp))
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = "${dueCards.size} Cards", fontSize = 20.sp, fontWeight = FontWeight.Black, color = TextPrimary)
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = CyberSurface),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.linearGradient(listOf(CyberSurfaceBorder, CyberEmeraldSuccess.copy(alpha = 0.5f)))
                        )
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "Mastered", fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = CyberEmeraldSuccess, modifier = Modifier.size(16.dp))
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = "${masteredCards.size} Cards", fontSize = 20.sp, fontWeight = FontWeight.Black, color = CyberEmeraldSuccess)
                        }
                    }
                }
            }

            // CARDS DUE TODAY
            item {
                Text(
                    text = "Cards Due for Active Review",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            if (dueCards.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = CyberEmeraldSuccess, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = "All caught up for today!", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(text = "No cards pending review right now. Tap '+' to create new concept cards.", fontSize = 12.sp, color = TextMuted, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                }
            } else {
                items(dueCards) { card ->
                    SpacedRevisionCardItem(
                        card = card,
                        onReview = { rating ->
                            viewModel.processRevisionReview(card, rating)
                        }
                    )
                }
            }

            // ALL REVISION CARDS
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "All Syllabus Flashcards (${revisionCards.size})",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            items(revisionCards) { card ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberSurface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = card.topicTitle, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(text = "${card.subjectName} • ${card.chapterName}", fontSize = 11.sp, color = CyberCyanSecondary)
                        }

                        val stageLabel = when (card.intervalStage) {
                            0 -> "Same Day"
                            1 -> "1 Day"
                            2 -> "3 Days"
                            3 -> "7 Days"
                            else -> "14 Days"
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (card.isMastered) CyberEmeraldSuccess.copy(alpha = 0.2f) else CyberSurfaceVariant)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (card.isMastered) "Mastered" else "Stage: $stageLabel",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (card.isMastered) CyberEmeraldSuccess else TextSecondary
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        FloatingActionButton(
            onClick = { showAddDialog = true },
            containerColor = CyberPurplePrimary,
            contentColor = Color.Black,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_flashcard_fab")
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Add Flashcard")
        }

        if (showAddDialog) {
            AddFlashcardDialog(
                subjects = subjects,
                onDismiss = { showAddDialog = false },
                onConfirm = { subId, subName, chapter, topic, concept ->
                    viewModel.addRevisionCard(subId, subName, chapter, topic, concept)
                    showAddDialog = false
                }
            )
        }
    }
}

@Composable
fun SpacedRevisionCardItem(
    card: RevisionCardEntity,
    onReview: (String) -> Unit
) {
    var isFlipped by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { isFlipped = !isFlipped }
            .testTag("revision_card_${card.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.horizontalGradient(listOf(CyberPurplePrimary.copy(alpha = 0.6f), CyberCyanSecondary.copy(alpha = 0.6f)))
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${card.subjectName} • ${card.chapterName}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyanSecondary
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Visibility, contentDescription = null, tint = TextMuted, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isFlipped) "Tap to Hide" else "Tap to Reveal",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Front: Question / Topic
            Text(
                text = card.topicTitle,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            // Back: Formula / Explanation
            AnimatedVisibility(visible = isFlipped) {
                Column {
                    Spacer(modifier = Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(CyberSurface)
                            .padding(14.dp)
                    ) {
                        Text(
                            text = card.keyConcept,
                            fontSize = 13.sp,
                            color = TextPrimary,
                            lineHeight = 19.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Easy, Difficult, Forgot Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onReview("FORGOT") },
                            modifier = Modifier.weight(1f).testTag("forgot_review_button_${card.id}"),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberRoseDanger.copy(alpha = 0.25f)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Forgot", color = CyberRoseDanger, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onReview("DIFFICULT") },
                            modifier = Modifier.weight(1f).testTag("difficult_review_button_${card.id}"),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberSurface),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Difficult", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onReview("EASY") },
                            modifier = Modifier.weight(1f).testTag("easy_review_button_${card.id}"),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberEmeraldSuccess.copy(alpha = 0.25f)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Easy", color = CyberEmeraldSuccess, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddFlashcardDialog(
    subjects: List<com.example.data.entity.SubjectEntity>,
    onDismiss: () -> Unit,
    onConfirm: (subId: Long, subName: String, chapter: String, topic: String, concept: String) -> Unit
) {
    var selectedSub by remember { mutableStateOf(subjects.firstOrNull()) }
    var chapterName by remember { mutableStateOf("") }
    var topicTitle by remember { mutableStateOf("") }
    var keyConcept by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberSurface,
        title = { Text("Add Revision Card", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = chapterName,
                    onValueChange = { chapterName = it },
                    label = { Text("Chapter (e.g. Motion, Periodic Table)") },
                    modifier = Modifier.fillMaxWidth().testTag("add_card_chapter_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = CyberPurplePrimary,
                        unfocusedBorderColor = CyberSurfaceBorder
                    )
                )

                OutlinedTextField(
                    value = topicTitle,
                    onValueChange = { topicTitle = it },
                    label = { Text("Question / Law / Topic Title") },
                    modifier = Modifier.fillMaxWidth().testTag("add_card_topic_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = CyberPurplePrimary,
                        unfocusedBorderColor = CyberSurfaceBorder
                    )
                )

                OutlinedTextField(
                    value = keyConcept,
                    onValueChange = { keyConcept = it },
                    label = { Text("Answer / Formula / Key Concept") },
                    modifier = Modifier.fillMaxWidth().testTag("add_card_concept_input"),
                    minLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = CyberCyanSecondary,
                        unfocusedBorderColor = CyberSurfaceBorder
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (topicTitle.isNotBlank() && keyConcept.isNotBlank()) {
                        val sub = selectedSub ?: subjects.firstOrNull()
                        onConfirm(
                            sub?.id ?: 1L,
                            sub?.name ?: "Science",
                            chapterName.ifBlank { "General" },
                            topicTitle,
                            keyConcept
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyberPurplePrimary),
                modifier = Modifier.testTag("confirm_add_card_button")
            ) {
                Text("Add Card", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceVariant)) {
                Text("Cancel", color = TextPrimary)
            }
        }
    )
}
