package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.ChapterEntity
import com.example.data.entity.DistractionAppEntity
import com.example.data.entity.MockExamEntity
import com.example.data.entity.RevisionCardEntity
import com.example.data.entity.StudySessionEntity
import com.example.data.entity.SubjectEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyDao {

    // --- SUBJECTS ---
    @Query("SELECT * FROM subjects ORDER BY id ASC")
    fun getAllSubjects(): Flow<List<SubjectEntity>>

    @Query("SELECT * FROM subjects WHERE id = :id LIMIT 1")
    suspend fun getSubjectById(id: Long): SubjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubject(subject: SubjectEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubjects(subjects: List<SubjectEntity>)

    @Update
    suspend fun updateSubject(subject: SubjectEntity)

    @Query("DELETE FROM subjects WHERE id = :id")
    suspend fun deleteSubject(id: Long)

    // --- CHAPTERS ---
    @Query("SELECT * FROM chapters WHERE subjectId = :subjectId ORDER BY chapterNumber ASC")
    fun getChaptersForSubject(subjectId: Long): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM chapters ORDER BY lastStudiedTimestamp DESC")
    fun getAllChapters(): Flow<List<ChapterEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapter(chapter: ChapterEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapters(chapters: List<ChapterEntity>)

    @Update
    suspend fun updateChapter(chapter: ChapterEntity)

    @Query("DELETE FROM chapters WHERE id = :id")
    suspend fun deleteChapter(id: Long)

    // --- STUDY SESSIONS ---
    @Query("SELECT * FROM study_sessions ORDER BY timestamp DESC")
    fun getAllSessions(): Flow<List<StudySessionEntity>>

    @Query("SELECT * FROM study_sessions WHERE timestamp >= :sinceTimestamp ORDER BY timestamp DESC")
    fun getSessionsSince(sinceTimestamp: Long): Flow<List<StudySessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: StudySessionEntity): Long

    // --- REVISION CARDS (Spaced Repetition) ---
    @Query("SELECT * FROM revision_cards ORDER BY nextReviewTimestamp ASC")
    fun getAllRevisionCards(): Flow<List<RevisionCardEntity>>

    @Query("SELECT * FROM revision_cards WHERE nextReviewTimestamp <= :nowTimestamp AND isMastered = 0 ORDER BY nextReviewTimestamp ASC")
    fun getDueRevisionCards(nowTimestamp: Long): Flow<List<RevisionCardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRevisionCard(card: RevisionCardEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRevisionCards(cards: List<RevisionCardEntity>)

    @Update
    suspend fun updateRevisionCard(card: RevisionCardEntity)

    @Query("DELETE FROM revision_cards WHERE id = :id")
    suspend fun deleteRevisionCard(id: Long)

    // --- MOCK EXAMS ---
    @Query("SELECT * FROM mock_exams ORDER BY timestamp DESC")
    fun getAllMockExams(): Flow<List<MockExamEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMockExam(exam: MockExamEntity): Long

    // --- DISTRACTION APPS ---
    @Query("SELECT * FROM distraction_apps ORDER BY appName ASC")
    fun getAllDistractionApps(): Flow<List<DistractionAppEntity>>

    @Query("SELECT * FROM distraction_apps WHERE isBlocked = 1")
    fun getBlockedApps(): Flow<List<DistractionAppEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDistractionApps(apps: List<DistractionAppEntity>)

    @Update
    suspend fun updateDistractionApp(app: DistractionAppEntity)

    @Query("UPDATE distraction_apps SET blockCount = blockCount + 1 WHERE packageName = :packageName")
    suspend fun incrementBlockCount(packageName: String)
}
