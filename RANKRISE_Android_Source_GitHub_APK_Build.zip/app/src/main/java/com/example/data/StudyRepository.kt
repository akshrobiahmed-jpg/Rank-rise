package com.example.data

import com.example.data.dao.StudyDao
import com.example.data.entity.ChapterEntity
import com.example.data.entity.DistractionAppEntity
import com.example.data.entity.MockExamEntity
import com.example.data.entity.RevisionCardEntity
import com.example.data.entity.StudySessionEntity
import com.example.data.entity.SubjectEntity
import kotlinx.coroutines.flow.Flow

class StudyRepository(private val dao: StudyDao) {

    val allSubjects: Flow<List<SubjectEntity>> = dao.getAllSubjects()
    val allChapters: Flow<List<ChapterEntity>> = dao.getAllChapters()
    val allSessions: Flow<List<StudySessionEntity>> = dao.getAllSessions()
    val allRevisionCards: Flow<List<RevisionCardEntity>> = dao.getAllRevisionCards()
    val allMockExams: Flow<List<MockExamEntity>> = dao.getAllMockExams()
    val distractionApps: Flow<List<DistractionAppEntity>> = dao.getAllDistractionApps()
    val blockedApps: Flow<List<DistractionAppEntity>> = dao.getBlockedApps()

    fun getChaptersForSubject(subjectId: Long): Flow<List<ChapterEntity>> =
        dao.getChaptersForSubject(subjectId)

    fun getSessionsSince(timestamp: Long): Flow<List<StudySessionEntity>> =
        dao.getSessionsSince(timestamp)

    fun getDueRevisionCards(now: Long): Flow<List<RevisionCardEntity>> =
        dao.getDueRevisionCards(now)

    suspend fun insertSubject(subject: SubjectEntity) = dao.insertSubject(subject)
    suspend fun updateSubject(subject: SubjectEntity) = dao.updateSubject(subject)
    suspend fun deleteSubject(id: Long) = dao.deleteSubject(id)

    suspend fun insertChapter(chapter: ChapterEntity) = dao.insertChapter(chapter)
    suspend fun updateChapter(chapter: ChapterEntity) = dao.updateChapter(chapter)
    suspend fun deleteChapter(id: Long) = dao.deleteChapter(id)

    suspend fun saveSession(session: StudySessionEntity) = dao.insertSession(session)

    suspend fun insertRevisionCard(card: RevisionCardEntity) = dao.insertRevisionCard(card)
    suspend fun updateRevisionCard(card: RevisionCardEntity) = dao.updateRevisionCard(card)
    suspend fun deleteRevisionCard(id: Long) = dao.deleteRevisionCard(id)

    suspend fun saveMockExam(exam: MockExamEntity) = dao.insertMockExam(exam)

    suspend fun updateDistractionApp(app: DistractionAppEntity) = dao.updateDistractionApp(app)
    suspend fun insertDistractionApp(app: DistractionAppEntity) = dao.insertDistractionApps(listOf(app))
    suspend fun incrementBlockCount(packageName: String) = dao.incrementBlockCount(packageName)

    suspend fun preloadIfNeeded() {
        RankRiseDatabase.populateInitialData(dao)
    }
}
