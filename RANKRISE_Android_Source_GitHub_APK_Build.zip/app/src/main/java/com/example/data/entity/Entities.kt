package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val banglaName: String,
    val colorHex: String,
    val iconName: String,
    val targetHours: Float = 15f,
    val isWeak: Boolean = false
)

@Entity(tableName = "chapters")
data class ChapterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val chapterNumber: Int,
    val title: String,
    val banglaTitle: String = "",
    val completionPercent: Int = 0, // 0 to 100
    val difficulty: String = "MEDIUM", // EASY, MEDIUM, HARD
    val isRevisionDone: Boolean = false,
    val notes: String = "",
    val photoUri: String? = null, // Path or Uri to attached photo / document
    val lastStudiedTimestamp: Long = 0L
)

@Entity(tableName = "study_sessions")
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val subjectName: String,
    val chapterTitle: String,
    val durationSeconds: Int,
    val mode: String, // POMO_25, POMO_50, DEEP_90, CUSTOM, STOPWATCH
    val timestamp: Long = System.currentTimeMillis(),
    val distractionsBlocked: Int = 0
)

@Entity(tableName = "revision_cards")
data class RevisionCardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val subjectName: String,
    val chapterName: String,
    val topicTitle: String,
    val keyConcept: String,
    val intervalStage: Int = 0, // 0 (same day), 1 (1d), 2 (3d), 3 (7d), 4 (14d)
    val nextReviewTimestamp: Long = System.currentTimeMillis(),
    val reviewCount: Int = 0,
    val isMastered: Boolean = false
)

@Entity(tableName = "mock_exams")
data class MockExamEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectName: String,
    val title: String,
    val score: Int,
    val totalQuestions: Int,
    val timeTakenSeconds: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val weakTopics: String = ""
)

@Entity(tableName = "distraction_apps")
data class DistractionAppEntity(
    @PrimaryKey val packageName: String,
    val appName: String,
    val isBlocked: Boolean = true,
    val blockCount: Int = 0
)
