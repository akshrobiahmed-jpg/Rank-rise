package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.StudyDao
import com.example.data.entity.ChapterEntity
import com.example.data.entity.DistractionAppEntity
import com.example.data.entity.MockExamEntity
import com.example.data.entity.RevisionCardEntity
import com.example.data.entity.StudySessionEntity
import com.example.data.entity.SubjectEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        SubjectEntity::class,
        ChapterEntity::class,
        StudySessionEntity::class,
        RevisionCardEntity::class,
        MockExamEntity::class,
        DistractionAppEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class RankRiseDatabase : RoomDatabase() {

    abstract fun studyDao(): StudyDao

    companion object {
        @Volatile
        private var INSTANCE: RankRiseDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): RankRiseDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    RankRiseDatabase::class.java,
                    "rankrise_study.db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.studyDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: StudyDao) {
            // Bangladesh Class 9 Science Subjects
            val defaultSubjects = listOf(
                SubjectEntity(id = 1, name = "Physics", banglaName = "পদার্থবিজ্ঞান", colorHex = "#A855F7", iconName = "speed", targetHours = 20f, isWeak = false),
                SubjectEntity(id = 2, name = "Chemistry", banglaName = "রসায়ন", colorHex = "#06B6D4", iconName = "science", targetHours = 20f, isWeak = true),
                SubjectEntity(id = 3, name = "Biology", banglaName = "জীববিজ্ঞান", colorHex = "#10B981", iconName = "eco", targetHours = 15f, isWeak = false),
                SubjectEntity(id = 4, name = "Higher Mathematics", banglaName = "উচ্চতর গণিত", colorHex = "#F59E0B", iconName = "functions", targetHours = 25f, isWeak = true),
                SubjectEntity(id = 5, name = "General Mathematics", banglaName = "সাধারণ গণিত", colorHex = "#38BDF8", iconName = "calculate", targetHours = 20f, isWeak = false),
                SubjectEntity(id = 6, name = "ICT", banglaName = "তথ্য ও যোগাযোগ প্রযুক্তি", colorHex = "#8B5CF6", iconName = "devices", targetHours = 12f, isWeak = false),
                SubjectEntity(id = 7, name = "Bangla", banglaName = "বাংলা", colorHex = "#EC4899", iconName = "menu_book", targetHours = 12f, isWeak = false),
                SubjectEntity(id = 8, name = "English", banglaName = "ইংরেজি", colorHex = "#6366F1", iconName = "language", targetHours = 14f, isWeak = false)
            )
            dao.insertSubjects(defaultSubjects)

            // Initial Chapters for Class 9 Science subjects (user can add/edit/upload syllabus photos)
            val defaultChapters = listOf(
                ChapterEntity(subjectId = 1, chapterNumber = 1, title = "Physical Quantities and Measurement", banglaTitle = "ভৌত রাশি এবং পরিমাপ", completionPercent = 80, difficulty = "EASY"),
                ChapterEntity(subjectId = 1, chapterNumber = 2, title = "Motion", banglaTitle = "গতি", completionPercent = 50, difficulty = "MEDIUM"),
                ChapterEntity(subjectId = 1, chapterNumber = 3, title = "Force", banglaTitle = "বল", completionPercent = 30, difficulty = "HARD"),
                ChapterEntity(subjectId = 1, chapterNumber = 4, title = "Work, Power and Energy", banglaTitle = "কাজ, ক্ষমতা ও শক্তি", completionPercent = 0, difficulty = "HARD"),
                
                ChapterEntity(subjectId = 2, chapterNumber = 1, title = "Concepts of Chemistry", banglaTitle = "রসায়নের ধারণা", completionPercent = 90, difficulty = "EASY"),
                ChapterEntity(subjectId = 2, chapterNumber = 2, title = "States of Matter", banglaTitle = "পদার্থের অবস্থা", completionPercent = 60, difficulty = "MEDIUM"),
                ChapterEntity(subjectId = 2, chapterNumber = 3, title = "Structure of Matter", banglaTitle = "পদার্থের গঠন", completionPercent = 20, difficulty = "HARD"),
                ChapterEntity(subjectId = 2, chapterNumber = 4, title = "Periodic Table", banglaTitle = "পর্যায় সারণি", completionPercent = 10, difficulty = "HARD"),

                ChapterEntity(subjectId = 3, chapterNumber = 1, title = "Lessons on Life", banglaTitle = "জীবন পাঠ", completionPercent = 75, difficulty = "EASY"),
                ChapterEntity(subjectId = 3, chapterNumber = 2, title = "Cells and Tissues", banglaTitle = "জীব কোষ ও টিস্যু", completionPercent = 40, difficulty = "MEDIUM"),

                ChapterEntity(subjectId = 4, chapterNumber = 1, title = "Set and Function", banglaTitle = "সেট ও ফাংশন", completionPercent = 65, difficulty = "MEDIUM"),
                ChapterEntity(subjectId = 4, chapterNumber = 2, title = "Algebraic Expressions", banglaTitle = "বীজগাণিতিক রাশি", completionPercent = 35, difficulty = "HARD")
            )
            dao.insertChapters(defaultChapters)

            // Default Distraction Apps to block during Exam Lock
            val defaultDistractionApps = listOf(
                DistractionAppEntity(packageName = "com.google.android.youtube", appName = "YouTube", isBlocked = true),
                DistractionAppEntity(packageName = "com.facebook.katana", appName = "Facebook", isBlocked = true),
                DistractionAppEntity(packageName = "com.instagram.android", appName = "Instagram", isBlocked = true),
                DistractionAppEntity(packageName = "com.zhiliaoapp.musically", appName = "TikTok", isBlocked = true),
                DistractionAppEntity(packageName = "com.twitter.android", appName = "X / Twitter", isBlocked = true),
                DistractionAppEntity(packageName = "com.snapchat.android", appName = "Snapchat", isBlocked = true),
                DistractionAppEntity(packageName = "com.reddit.frontpage", appName = "Reddit", isBlocked = true)
            )
            dao.insertDistractionApps(defaultDistractionApps)

            // Initial Revision Cards
            val now = System.currentTimeMillis()
            val defaultRevisionCards = listOf(
                RevisionCardEntity(
                    subjectId = 1,
                    subjectName = "Physics",
                    chapterName = "Motion",
                    topicTitle = "Newton's First Law of Motion",
                    keyConcept = "An object remains at rest or in uniform motion unless acted upon by a net external force. Relates to inertia.",
                    intervalStage = 0,
                    nextReviewTimestamp = now
                ),
                RevisionCardEntity(
                    subjectId = 2,
                    subjectName = "Chemistry",
                    chapterName = "Structure of Matter",
                    topicTitle = "Bohr's Atomic Model Postulates",
                    keyConcept = "Electrons revolve in discrete stationary orbits without radiating energy. Angular momentum mvr = nh / 2π.",
                    intervalStage = 0,
                    nextReviewTimestamp = now
                ),
                RevisionCardEntity(
                    subjectId = 4,
                    subjectName = "Higher Math",
                    chapterName = "Algebraic Expressions",
                    topicTitle = "Remainder Theorem",
                    keyConcept = "If a polynomial P(x) is divided by (x - a), the remainder is P(a).",
                    intervalStage = 1,
                    nextReviewTimestamp = now + 86400000L
                )
            )
            dao.insertRevisionCards(defaultRevisionCards)
        }
    }
}
