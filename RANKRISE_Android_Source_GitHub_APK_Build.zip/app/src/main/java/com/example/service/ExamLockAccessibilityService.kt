package com.example.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.example.MainActivity

class ExamLockAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        ExamLockManager.setAccessibilityEnabled(true)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            return
        }

        val packageName = event.packageName?.toString() ?: return

        // Skip our own app
        if (packageName == applicationContext.packageName) {
            return
        }

        // If focus session is active and opened app is in blocked list
        if (ExamLockManager.isFocusActive.value) {
            val blockedSet = ExamLockManager.blockedPackages.value
            if (blockedSet.contains(packageName)) {
                // Intercept and bring user back to RANKRISE study screen
                ExamLockManager.onDistractionDetected(packageName, packageName)

                val intent = Intent(this, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_DISTRACTION_INTERCEPTED", true)
                    putExtra("EXTRA_INTERCEPTED_PACKAGE", packageName)
                }
                startActivity(intent)
            }
        }
    }

    override fun onInterrupt() {
        // Required callback when accessibility service is interrupted
    }

    override fun onDestroy() {
        ExamLockManager.setAccessibilityEnabled(false)
        super.onDestroy()
    }
}
