package com.example.service

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

object ExamLockManager {
    private val _isFocusActive = MutableStateFlow(false)
    val isFocusActive = _isFocusActive.asStateFlow()

    private val _currentSessionInfo = MutableStateFlow("Focusing on Class 9 Science")
    val currentSessionInfo = _currentSessionInfo.asStateFlow()

    private val _remainingTimeSeconds = MutableStateFlow(0)
    val remainingTimeSeconds = _remainingTimeSeconds.asStateFlow()

    private val _blockedPackages = MutableStateFlow<Set<String>>(emptySet())
    val blockedPackages = _blockedPackages.asStateFlow()

    private val _distractionCount = MutableStateFlow(0)
    val distractionCount = _distractionCount.asStateFlow()

    // Event when an app was intercepted
    private val _interceptEvent = MutableSharedFlow<String>(extraBufferCapacity = 5)
    val interceptEvent = _interceptEvent.asSharedFlow()

    private val _isAccessibilityEnabled = MutableStateFlow(false)
    val isAccessibilityEnabled = _isAccessibilityEnabled.asStateFlow()

    fun setAccessibilityEnabled(enabled: Boolean) {
        _isAccessibilityEnabled.value = enabled
    }

    fun startFocusSession(sessionTitle: String, totalSeconds: Int, blockedSet: Set<String>) {
        _currentSessionInfo.value = sessionTitle
        _remainingTimeSeconds.value = totalSeconds
        _blockedPackages.value = blockedSet
        _isFocusActive.value = true
    }

    fun updateRemainingTime(seconds: Int) {
        _remainingTimeSeconds.value = seconds
    }

    fun stopFocusSession() {
        _isFocusActive.value = false
    }

    fun onDistractionDetected(packageName: String, appName: String) {
        _distractionCount.value += 1
        _interceptEvent.tryEmit(appName)
    }

    fun resetDistractionCount() {
        _distractionCount.value = 0
    }
}
