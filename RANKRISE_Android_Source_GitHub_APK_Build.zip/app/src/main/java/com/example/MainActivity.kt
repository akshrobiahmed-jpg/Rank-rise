package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.StudyViewModel
import com.example.ui.components.DistractionBanner
import com.example.ui.components.RankRiseBottomNav
import com.example.ui.screens.AiCoachScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ExamLockScreen
import com.example.ui.screens.MockExamsScreen
import com.example.ui.screens.PlannerScreen
import com.example.ui.screens.RevisionScreen
import com.example.ui.screens.SubjectsScreen
import com.example.ui.screens.TimerScreen
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val studyViewModel: StudyViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        handleDistractionIntent(intent)

        setContent {
            MyApplicationTheme {
                RankRiseApp(studyViewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleDistractionIntent(intent)
    }

    private fun handleDistractionIntent(intent: Intent?) {
        if (intent?.getBooleanExtra("EXTRA_DISTRACTION_INTERCEPTED", false) == true) {
            val pkg = intent.getStringExtra("EXTRA_INTERCEPTED_PACKAGE") ?: "Distraction App"
            studyViewModel.lastInterceptedApp.value = pkg
            studyViewModel.currentScreen.value = "timer"
        }
    }
}

@Composable
fun RankRiseApp(viewModel: StudyViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val interceptedApp by viewModel.lastInterceptedApp.collectAsStateWithLifecycle()

    // Handle back button for secondary screens
    if (currentScreen !in listOf("dashboard", "timer", "subjects", "revision", "ai_coach")) {
        BackHandler {
            viewModel.currentScreen.value = "dashboard"
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = CyberBackground,
        bottomBar = {
            if (currentScreen in listOf("dashboard", "timer", "subjects", "revision", "ai_coach")) {
                RankRiseBottomNav(
                    currentRoute = currentScreen,
                    onNavigate = { route -> viewModel.currentScreen.value = route }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(CyberBackground)
                .padding(innerPadding)
        ) {
            // Distraction Alert Banner if an app was intercepted
            DistractionBanner(
                appName = interceptedApp,
                onDismiss = { viewModel.dismissDistractionBanner() }
            )

            Box(modifier = Modifier.weight(1f)) {
                when (currentScreen) {
                    "dashboard" -> DashboardScreen(viewModel = viewModel)
                    "timer" -> TimerScreen(viewModel = viewModel)
                    "subjects" -> SubjectsScreen(viewModel = viewModel)
                    "revision" -> RevisionScreen(viewModel = viewModel)
                    "ai_coach" -> AiCoachScreen(viewModel = viewModel)
                    "mock_exams" -> MockExamsScreen(viewModel = viewModel)
                    "planner" -> PlannerScreen(viewModel = viewModel)
                    "exam_lock_settings" -> ExamLockScreen(viewModel = viewModel)
                    else -> DashboardScreen(viewModel = viewModel)
                }
            }
        }
    }
}
