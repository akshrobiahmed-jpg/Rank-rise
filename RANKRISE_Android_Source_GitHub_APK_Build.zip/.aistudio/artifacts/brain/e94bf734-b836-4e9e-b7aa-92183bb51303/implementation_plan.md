# RANKRISE — Native Android Study & 30-Day Exam Preparation App

A high-performance native Android application engineered for Class 9 Science students preparing for board and school examinations within 30 days. RANKRISE combines precision study timers, customizable NCTB science subjects with photo/document attachments, an active Exam Lock distraction shield, 30-day adaptive scheduling, Leitner spaced repetition, and an intelligent AI study coach.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following key decisions have been confirmed and integrated into this architecture:

- **Confirmed — Syllabus & Document Upload**: Preloaded with core Bangladesh Class 9 Science subjects (Physics, Chemistry, Biology, Higher Math, General Math, Bangla, English, ICT) along with a native photo and file picker to attach textbook pages, homework photos, syllabus sheets, and question banks to chapters.
- **Confirmed — Visual Aesthetic**: Deep cyber dark theme (`#0D0B18` surface) with glowing electric purple (`#A855F7`), neon cyan/blue (`#06B6D4`), and violet accents matching the custom brand emblem.
- **Confirmed — Exam Lock Distraction Shield**: Android `AccessibilityService` integration to monitor foreground packages during active focus sessions, detect distracting apps (e.g. YouTube, TikTok, Facebook, Instagram), and display an immediate blocking overlay with remaining timer countdown and an Emergency Override option.
- **Confirmed — Local Storage & Offline Engine**: 100% offline-first architecture using Room Database (`SQLite`) with DAOs and reactive `StateFlow` for immediate updates and zero data loss across reboots.

---

## 1. Overview & Core Concept

- **What It Does**: RANKRISE acts as an all-in-one academic command center. It tracks daily study hours against a 30-day countdown, provides customizable Pomodoro and Deep Work timers with background recovery, tracks syllabus completion across all science and general subjects, schedules spaced repetition reviews, blocks distracting apps during focus hours, and provides an AI Study Coach for step-by-step math and science explanations.
- **Target Audience / Persona**: Class 9 Science students in Bangladesh (NCTB curriculum) preparing for critical term/annual exams under a strict 30-day timeline.
- **Key Value**: Eliminates exam anxiety and phone distractions through automated daily study targets, active focus enforcement, and instant multimodal academic guidance.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Dashboard & Quick Start**:
   - Dynamic 30-day countdown banner with glowing progress ring.
   - Today's focused hours vs daily target (e.g., 4.5 hrs / 6.0 hrs).
   - "One-Tap Start Studying" floating action card launching into the active timer.
   - Quick glance at weak subjects, daily streak, and pending spaced-repetition cards.
2. **Advanced Focus Timer**:
   - Mode presets: 25/5 Pomodoro, 50/10 Focus, 90/15 Deep Work, Custom Timer, and Free Stopwatch.
   - Circular animated progress dial with glowing neon trail and breathing ambient pulse.
   - Subject & chapter tagging for every session.
   - Distraction Shield toggle (triggers Exam Lock).
3. **Subjects & Chapter Tracker**:
   - Preloaded cards: Physics (পদার্থবিজ্ঞান), Chemistry (রসায়ন), Biology (জীববিজ্ঞান), Higher Math (উচ্চতর গণিত), General Math (সাধারণ গণিত), ICT (তথ্য ও যোগাযোগ প্রযুক্তি), Bangla, English.
   - Chapter drill-down: add/edit chapters, mark completion %, difficulty rating (Easy/Medium/Hard), and attach syllabus photos or notes via Android Photo Picker.
4. **Exam Lock Distraction Shield**:
   - User-managed blacklist of distracting apps (YouTube, Facebook, Instagram, TikTok, Games).
   - Clear disclosure and permission flow to enable the native `AccessibilityService`.
   - When a blacklisted app is opened during a focus session, RANKRISE brings up an overlay: *"Stay Focused on Class 9 Science!"*, showing remaining session time and an emergency unlock option (with friction delay).
5. **30-Day Adaptive Planner & Revision Center**:
   - Automatically distributes remaining chapters across the remaining exam days based on difficulty and completed status.
   - Spaced Repetition engine using review intervals (Same Day, 1 Day, 3 Days, 7 Days, 14 Days) with Easy, Difficult, and Forgot rating buttons.
6. **AI Study Coach & Mock Exams**:
   - Bilingual (English and বাংলা) academic solver.
   - Upload or snap photos of complex math problems, chemical equations, or physics derivations for step-by-step breakdown.
   - Generate instant 10-question timed MCQ quizzes on specific science chapters with automated grading and weak-topic diagnostics.

### Visual Identity & Theme Tokens

- **Background**: Deep Space Black (`#0B0814`) with dark obsidian cards (`#151026`) and subtle glowing neon borders (`#2D1F4D`).
- **Primary Accent**: Electric Violet (`#8B5CF6`) and Royal Purple (`#7C3AED`).
- **Secondary Accent**: Cyber Cyan / Electric Blue (`#06B6D4` / `#38BDF8`).
- **Warning & Exam Alert**: Vivid Amber / Coral (`#F59E0B` / `#F43F5E`).
- **Typography**: Clean, high-legibility sans-serif with bold tabular figures for timer countdowns and crisp metric cards.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Local Room Database as Single Source of Truth**
  - *Chosen Approach*: Store subjects, chapters, study logs, revision items, and quiz results directly in Room.
  - *Why*: High school students often study offline or with mobile data turned off to avoid distractions; Room provides instant, reliable zero-latency data persistence.
- **Decision 2: Accessible Exam Lock Overlay with Emergency Exit**
  - *Chosen Approach*: Implement an Android `AccessibilityService` that inspects foreground package names during an active timer, paired with an `AlertWindow` overlay or direct intent launch back to RANKRISE.
  - *Why*: Native, privacy-respecting, adheres to Android security requirements without requiring root access, and includes an emergency override button so users are never trapped.
- **Decision 3: Android Photo Picker for Syllabus and Question Uploads**
  - *Chosen Approach*: Use `ActivityResultContracts.PickVisualMedia` and `GetContent` for selecting images and documents without requesting sensitive storage permissions.
  - *Why*: Google Play policy compliant, zero runtime permissions required, and seamless gallery access for capturing textbook diagrams and notes.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Jetpack Compose UI Layer                        │
│  ┌───────────────┐ ┌───────────────┐ ┌────────────────┐ ┌────────────┐ │
│  │   Dashboard   │ │  Focus Timer  │ │    Subjects    │ │  Revision  │ │
│  │ (Metrics/FAB) │ │ (Pomo/D-Work) │ │ (Chapters/Doc) │ │  (Spaced)  │ │
│  └───────┬───────┘ └───────┬───────┘ └────────┬───────┘ └──────┬─────┘ │
│          │                 │                  │                │       │
│  ┌───────┴─────────────────┴──────────────────┴────────────────┴─────┐ │
│  │                         AppViewModel                              │ │
│  │    • Session Timer State      • 30-Day Plan State                 │ │
│  │    • Room Reactive Flows      • AI Study Query / Quiz State       │ │
│  └───────────────────────────────┬───────────────────────────────────┘ │
└──────────────────────────────────┼─────────────────────────────────────┘
                                   │
┌──────────────────────────────────┴─────────────────────────────────────┐
│                       Data Layer & Services                            │
│  ┌───────────────────────────┐    ┌──────────────────────────────────┐ │
│  │       StudyRepository     │    │        ExamLockService           │ │
│  │  • SubjectDao             │    │  (AccessibilityService)          │ │
│  │  • ChapterDao             │    │  • Blacklist package detection   │ │
│  │  • StudySessionDao        │    │  • Intercept & Return to App     │ │
│  │  • RevisionItemDao        │    └──────────────────────────────────┘ │
│  │  • MockExamDao            │    ┌──────────────────────────────────┐ │
│  └─────────────┬─────────────┘    │        GeminiStudyCoach          │ │
│                │                  │  • Multimodal math & science     │ │
│  ┌─────────────┴─────────────┐    │  • NCTB MCQ & quiz generator     │ │
│  │   RankRiseDatabase (Room) │    └──────────────────────────────────┘ │
│  │   (Offline SQLite Engine) │                                         │
│  └───────────────────────────┘                                         │
└────────────────────────────────────────────────────────────────────────┘
```

### Core Entities & State

- **`SubjectEntity`**: `id`, `name`, `banglaName`, `colorHex`, `iconName`, `targetHours`, `examDate`.
- **`ChapterEntity`**: `id`, `subjectId`, `chapterNumber`, `title`, `completionPercent`, `difficulty` (EASY, MEDIUM, HARD), `notes`, `attachedImageUri`, `lastStudiedTimestamp`.
- **`StudySessionEntity`**: `id`, `subjectId`, `chapterId`, `durationSeconds`, `mode` (POMODORO, DEEP_WORK, STOPWATCH), `timestamp`, `distractionsBlockedCount`.
- **`RevisionCardEntity`**: `id`, `chapterId`, `topicTitle`, `keyPoints`, `intervalDays` (0, 1, 3, 7, 14), `nextReviewTimestamp`, `repetitionLevel`, `easeFactor`.
- **`MockExamEntity`**: `id`, `subjectId`, `title`, `score`, `totalQuestions`, `timeTakenSeconds`, `dateTimestamp`, `weakTopicsSummary`.

---

## Plan Status: Ready for User Review

Review the blueprint above. Upon your approval, we will immediately set up the app launcher icon, build the Room entities and DAOs, implement the cyber-dark theme, construct all 5 primary screens (Dashboard, Timer, Subjects with photo uploads, Revision Center, Profile/Planner), and build the native Exam Lock accessibility service.
