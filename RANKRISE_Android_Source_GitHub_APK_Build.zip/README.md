# RANKRISE — Android Study Planner

A native Android study companion built with Kotlin and Jetpack Compose for a 30-day Class 9 Science exam-preparation workflow.

## Included

- Dark dashboard with study progress
- Focus timer and study-session tracking
- Subject and revision screens
- Study planner and mock-exam screens
- AI study-coach integration hooks
- Optional accessibility-based Exam Lock screen
- Room database for local study data

## Build an APK with GitHub Actions

1. Upload the **contents** of this project folder to the root of your GitHub repository. Keep the hidden `.github` folder.
2. Push or merge the files into the `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build RANKRISE Android APK**. A push to `main` starts it automatically; you can also use **Run workflow**.
5. Open the completed run and download the `RANKRISE-debug-APK` artifact. Extract the downloaded artifact ZIP to get `app-debug.apk`.
6. Transfer the APK to your Android phone and install it. You may need to allow your file manager/browser to install unknown apps.

## Local build requirements

- Android Studio with Android SDK Platform 36
- JDK 17
- Gradle 9.3.1

The GitHub workflow installs Gradle 9.3.1 directly, so a Gradle wrapper is not required for the CI build.

## Important

- The workflow creates a **debug APK for testing**, not a Play Store release.
- It generates a temporary debug signing key on each run. If you install a later APK and Android reports a signature mismatch, uninstall the previous test build first.
- The AI coach may require a valid Gemini/Firebase configuration. Do not commit API keys, `.env` files, service-account files, or private signing keys.
- Exam Lock uses Android Accessibility Service functionality. The user must explicitly enable the service in Android Settings; Android does not allow an app to silently enable it.
- The workflow has been prepared, but a successful GitHub Actions run is still required to confirm the final APK build.
