# Build RANKRISE APK on GitHub

1. Upload every item inside this folder to the repository root. Include `.github/workflows/android-apk.yml`; do not upload only the outer folder.
2. Commit the files to `main`.
3. Go to **Actions** → **Build RANKRISE Android APK**.
4. Wait for the build job to finish successfully.
5. Open the workflow run and download the `RANKRISE-debug-APK` artifact.
6. Extract the artifact ZIP; the APK is named `app-debug.apk`.

A push to `main` or a pull request targeting `main` also triggers the workflow. The workflow installs JDK 17, Android SDK Platform 36, Build Tools 36.0.0, and Gradle 9.3.1, then runs `:app:assembleDebug`.

This is a debug build for testing, not a signed Play Store release. The workflow creates a temporary debug key each time.
